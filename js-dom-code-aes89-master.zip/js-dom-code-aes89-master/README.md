# DOM

This is starter code for the Javascript DOM lesson.

This code is referenced and modified in the lesson.