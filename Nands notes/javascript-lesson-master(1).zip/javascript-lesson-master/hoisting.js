var name = "tom";

// javascript engine - performs hoisting
var name;
// console.log(name)
name = "tom";
// console.log(name)

// common standrad called ECMA SCRIpt


// mocha - live script - javascript - ecmascript


// chrome -  v8(javascript interpreters)
// mozilla - spider monkey
// Internet explorer - V8


// declare variable in ES5 :

// var name = "Kalyani";
// // block : function, if else, for loop

// {
//     var name = "tom"
//     console.log(name)
// }

// console.log(name);

// es 6: two more var type were introcued, let and const
// var name = "Kalyani";
// // block : function, if else, for loop

// {
//     let name = "tom"
//     console.log(name)
// }

// console.log(name);

// const name = "brodie";
// name = "tom";

// console.log(name);
// const data = require('some package') // Es6

// global as var
// block level variables should be let
// const at global or at block level if you don't want to change it value
// {
//     var name = "brodie";
//     console.log(name);
// }
// console.log(name);

// string interpolation

name = "tom"
// puts 'my name is #{name}'

console.log(`my name is ${name}`)


