// type coercion :  when you have two differnt dataypes involved in an operation, based on the operation on get converted to another

console.log(1 / '2')
console.log(1 / "callum")
