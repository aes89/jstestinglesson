// bad code
let name = "maya"
{
    const name = "sarah";
    console.log(name);
}
console.log(name);