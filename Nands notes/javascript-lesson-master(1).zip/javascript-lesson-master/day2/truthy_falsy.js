// falsy values:
// 0
// ""
// NaN
// null
// undefined

// everything else is a truthy value

// console.log(false || 10);
// console.log(false && 10);
console.log(NaN && 10);
console.log("" && 10);

console.log(10 && 20);
console.log(10 || 20);





