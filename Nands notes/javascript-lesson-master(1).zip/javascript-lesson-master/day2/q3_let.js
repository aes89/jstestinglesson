// scope is limited to the block
{
    let x = "maya"
    console.log(x);
}

console.log(x);