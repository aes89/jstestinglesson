{
    var x = "maya"
    console.log(x);
}
console.log(x)