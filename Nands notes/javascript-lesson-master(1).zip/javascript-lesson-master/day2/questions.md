## what does dynamically typed mean?
## example?
## What is the default value browser sets if the variable has no value assigned?
## Should a keyword be used while re-assigning a value to the variable already defined
## What are the different keywords used to declare a variable
## How do you declare a variable of type integer?
## Explain type coercion

* 16 + 4 + "cats"
* "Cats" + 16  +4
*  Number(null)
*  Number(undefined)
* null == undefined
*  null === undefined
