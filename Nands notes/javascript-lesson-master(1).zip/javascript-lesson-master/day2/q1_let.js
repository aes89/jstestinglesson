// good code
var x = "sarah";
{
    let x = "maya"
    console.log(x);
}

console.log(x);