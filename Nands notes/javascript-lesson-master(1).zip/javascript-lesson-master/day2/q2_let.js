// bad practice
let x = "sarah";
{
    let x = "maya"
    console.log(x);
}

console.log(x);