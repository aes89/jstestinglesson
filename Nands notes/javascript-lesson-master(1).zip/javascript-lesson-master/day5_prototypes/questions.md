<!-- should we stick to functions or classes or both?

https://reactjs.org/docs/hooks-faq.html
https://reactjs.org/docs/hooks-faq.html#should-i-use-hooks-classes-or-a-mix-of-both -->

