puts "What is your name"
name = gets.chomp
puts "hello #{name}"