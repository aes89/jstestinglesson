console.log("before timer starts")


// exceutes a callback after certain time has passes
// setTimeout(callback, 5000)


setTimeout(() => {
    console.log("5 sec completed")
}, 5000)


console.log("finished")