## package.json: to install all packages
how to create package.json ? - npm init
installed express: npm i express
created script: start
required express and created a get route
started listening for server
installed nodemon : to auto restart server

