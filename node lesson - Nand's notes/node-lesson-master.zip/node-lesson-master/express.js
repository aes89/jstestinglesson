const express = () => {
    get
    post
}
module.export = {
    express
}